// Background script for screen capture functionality
console.log('🔄 Background script 로드됨');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Background script 메시지 수신:', request);
  
  if (request.action === 'ping') {
    console.log('🏓 Ping 요청 수신');
    sendResponse({ success: true, message: 'Background script is alive' });
    return true;
  }
  
  if (request.action === 'captureScreen') {
    console.log('📸 화면 캡처 요청 처리 중...');
    
    // 현재 활성 탭에서 화면 캡처
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      console.log('📋 활성 탭 조회 결과:', tabs);
      
      if (tabs && tabs[0]) {
        console.log('✅ 활성 탭 발견:', tabs[0].id, tabs[0].url);
        
        chrome.tabs.captureVisibleTab(tabs[0].windowId, { format: 'png' }, (dataUrl) => {
          if (chrome.runtime.lastError) {
            console.error('❌ 화면 캡처 실패:', chrome.runtime.lastError);
            sendResponse({ success: false, error: chrome.runtime.lastError.message });
          } else {
            console.log('✅ 화면 캡처 성공! 데이터 URL 길이:', dataUrl ? dataUrl.length : 0);
            sendResponse({ success: true, dataUrl: dataUrl });
          }
        });
      } else {
        console.error('❌ 활성 탭을 찾을 수 없음');
        sendResponse({ success: false, error: 'No active tab found' });
      }
    });
    return true; // 비동기 응답을 위해 true 반환
  }
  
  console.log('⚠️ 알 수 없는 액션:', request.action);
  sendResponse({ success: false, error: 'Unknown action' });
}); 